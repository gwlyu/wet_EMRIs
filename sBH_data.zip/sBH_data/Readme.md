sBH samples from arXiv:2112.10237, Table II



There are 2000 rows/samples in every samp files, 13 columns:
z, d, M, T, e0, i0, tS, tK, gamma, psi, pS, pK, alpha


The snr files list snrs of every 2000 samples




